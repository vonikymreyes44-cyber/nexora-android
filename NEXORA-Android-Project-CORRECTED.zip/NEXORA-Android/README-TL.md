# NEXORA Business Suite — Android WebView App

Ito ang Android Studio project para sa NEXORA APK.

## App details
- App name: NEXORA Business Suite
- Package: `com.nexora.businesssuite`
- Start page: `https://nexora.totoboostingsite.com/dashboard.php`
- Full-screen immersive mode (Android status/navigation bars are hidden while the app is active)
- JavaScript, DOM storage, and cookies enabled para gumana ang website login/session.

## Paano gumawa ng APK
1. I-install ang Android Studio sa Windows PC/laptop.
2. I-extract ang ZIP.
3. Sa Android Studio, piliin ang **Open** at piliin ang extracted `NEXORA-Android` folder.
4. Hintaying matapos ang Gradle Sync. Kailangan ng internet sa unang sync para ma-download ang Android Gradle Plugin at dependencies.
5. Piliin ang **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Kapag successful, piliin ang **locate** sa notification. Ang APK ay karaniwang nasa:
   `app/build/outputs/apk/debug/app-debug.apk`
7. I-copy ang APK sa Android phone at i-install. Maaaring kailanganing payagan ang installation from that source.

## Importanteng limitasyon
- Ito ay WebView wrapper: kailangan ng internet at naka-host pa rin ang NEXORA website.
- Hindi ito offline ERP app.
- Ang APK ay para sa Android; hindi ito direktang mai-install sa Windows desktop.
- Sa desktop, website/PWA installation ang hiwalay na gagawin.
- Hindi pa ito na-build o nasubukan sa Android device sa environment na ito dahil walang Android SDK/Gradle build tools dito.

## App icon
Kasama na ang custom NEXORA launcher icon sa `app/src/main/res/mipmap-nodpi/ic_launcher.png` at naka-link na ito sa AndroidManifest.
